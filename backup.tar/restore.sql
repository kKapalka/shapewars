--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.0
-- Dumped by pg_dump version 11.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "shape-wars";
--
-- Name: shape-wars; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "shape-wars" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Polish_Poland.1250' LC_CTYPE = 'Polish_Poland.1250';


ALTER DATABASE "shape-wars" OWNER TO postgres;

\connect -reuse-previous=on "dbname='shape-wars'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: changelog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.changelog (
    changelog_id bigint NOT NULL,
    change character varying(255),
    change_time timestamp without time zone
);


ALTER TABLE public.changelog OWNER TO postgres;

--
-- Name: color; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.color (
    color_id bigint NOT NULL,
    color_map bytea,
    color_name character varying(255)
);


ALTER TABLE public.color OWNER TO postgres;

--
-- Name: color_damage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.color_damage (
    color_damage_id bigint NOT NULL,
    damage_percentage bigint,
    enemy_color_id bigint,
    color_id bigint NOT NULL
);


ALTER TABLE public.color_damage OWNER TO postgres;

--
-- Name: exp_threshold; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exp_threshold (
    exp_threshold_id bigint NOT NULL,
    level bigint,
    threshold bigint
);


ALTER TABLE public.exp_threshold OWNER TO postgres;

--
-- Name: fight; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fight (
    fight_id bigint NOT NULL,
    fight_status character varying(255),
    player_one_id bigint,
    player_two_id bigint
);


ALTER TABLE public.fight OWNER TO postgres;

--
-- Name: fight_action; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fight_action (
    fight_action_id bigint NOT NULL,
    action_time timestamp without time zone,
    active_fighter_id bigint,
    fight_id bigint,
    next_active_fighter_id bigint,
    selected_target_id bigint,
    skill_id bigint
);


ALTER TABLE public.fight_action OWNER TO postgres;

--
-- Name: fighter; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fighter (
    fighter_id bigint NOT NULL,
    armor_mod bigint,
    xp_points bigint,
    hitpoints_mod bigint,
    level bigint,
    slot character varying(255),
    strength_mod bigint,
    fighter_model_referrence_id bigint,
    owner_id bigint
);


ALTER TABLE public.fighter OWNER TO postgres;

--
-- Name: fighter_model_referrence; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fighter_model_referrence (
    fighter_model_referrence_id bigint NOT NULL,
    fighter_image bytea,
    color_id bigint,
    shape_id bigint
);


ALTER TABLE public.fighter_model_referrence OWNER TO postgres;

--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO postgres;

--
-- Name: maintenance_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.maintenance_log (
    maintenance_log_time bigint NOT NULL,
    message character varying(255),
    message_time timestamp without time zone,
    message_type character varying(255),
    informer_id bigint
);


ALTER TABLE public.maintenance_log OWNER TO postgres;

--
-- Name: message; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.message (
    message_id bigint NOT NULL,
    message character varying(255),
    message_time timestamp without time zone,
    receiver_id bigint,
    user_id bigint
);


ALTER TABLE public.message OWNER TO postgres;

--
-- Name: shape; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shape (
    shape_id bigint NOT NULL,
    arm_max_growth bigint,
    arm_min_growth bigint,
    hp_max_growth bigint,
    hp_min_growth bigint,
    str_max_growth bigint,
    str_min_growth bigint,
    baseline_arm bigint,
    baseline_hp bigint,
    baseline_str bigint,
    image bytea,
    name character varying(255),
    speed bigint
);


ALTER TABLE public.shape OWNER TO postgres;

--
-- Name: shape_skill; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shape_skill (
    shape_id bigint NOT NULL,
    skill_id bigint NOT NULL
);


ALTER TABLE public.shape_skill OWNER TO postgres;

--
-- Name: skill; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.skill (
    skill_id bigint NOT NULL,
    cost bigint,
    icon bytea,
    name character varying(255),
    tooltip text
);


ALTER TABLE public.skill OWNER TO postgres;

--
-- Name: skill_effect; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.skill_effect (
    skill_effect_id bigint NOT NULL,
    max_value double precision,
    min_value double precision,
    effect character varying(255),
    target_type character varying(255),
    value_modifier_type character varying(255),
    skill_effect_bundle_id bigint
);


ALTER TABLE public.skill_effect OWNER TO postgres;

--
-- Name: skill_effect_bundle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.skill_effect_bundle (
    skill_effect_bundle_id bigint NOT NULL,
    accuracy double precision,
    skill_id bigint
);


ALTER TABLE public.skill_effect_bundle OWNER TO postgres;

--
-- Name: skill_effect_result; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.skill_effect_result (
    skill_effect_result_id bigint NOT NULL,
    result double precision,
    effect character varying(255),
    value_modifier_type character varying(255),
    target_id bigint,
    fight_action_id bigint
);


ALTER TABLE public.skill_effect_result OWNER TO postgres;

--
-- Name: turn_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.turn_order (
    turn_order_id bigint NOT NULL,
    turn_order bigint,
    turn bigint,
    fight_id bigint,
    fighter_id bigint
);


ALTER TABLE public.turn_order OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id bigint NOT NULL,
    admin boolean,
    email character varying(255),
    xp_points bigint,
    level bigint,
    login character varying(255),
    password character varying(255),
    verified boolean
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: changelog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.changelog (changelog_id, change, change_time) FROM stdin;
\.
COPY public.changelog (changelog_id, change, change_time) FROM '$$PATH$$/2940.dat';

--
-- Data for Name: color; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.color (color_id, color_map, color_name) FROM stdin;
\.
COPY public.color (color_id, color_map, color_name) FROM '$$PATH$$/2941.dat';

--
-- Data for Name: color_damage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.color_damage (color_damage_id, damage_percentage, enemy_color_id, color_id) FROM stdin;
\.
COPY public.color_damage (color_damage_id, damage_percentage, enemy_color_id, color_id) FROM '$$PATH$$/2942.dat';

--
-- Data for Name: exp_threshold; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exp_threshold (exp_threshold_id, level, threshold) FROM stdin;
\.
COPY public.exp_threshold (exp_threshold_id, level, threshold) FROM '$$PATH$$/2943.dat';

--
-- Data for Name: fight; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fight (fight_id, fight_status, player_one_id, player_two_id) FROM stdin;
\.
COPY public.fight (fight_id, fight_status, player_one_id, player_two_id) FROM '$$PATH$$/2944.dat';

--
-- Data for Name: fight_action; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fight_action (fight_action_id, action_time, active_fighter_id, fight_id, next_active_fighter_id, selected_target_id, skill_id) FROM stdin;
\.
COPY public.fight_action (fight_action_id, action_time, active_fighter_id, fight_id, next_active_fighter_id, selected_target_id, skill_id) FROM '$$PATH$$/2958.dat';

--
-- Data for Name: fighter; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fighter (fighter_id, armor_mod, xp_points, hitpoints_mod, level, slot, strength_mod, fighter_model_referrence_id, owner_id) FROM stdin;
\.
COPY public.fighter (fighter_id, armor_mod, xp_points, hitpoints_mod, level, slot, strength_mod, fighter_model_referrence_id, owner_id) FROM '$$PATH$$/2945.dat';

--
-- Data for Name: fighter_model_referrence; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fighter_model_referrence (fighter_model_referrence_id, fighter_image, color_id, shape_id) FROM stdin;
\.
COPY public.fighter_model_referrence (fighter_model_referrence_id, fighter_image, color_id, shape_id) FROM '$$PATH$$/2946.dat';

--
-- Data for Name: maintenance_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.maintenance_log (maintenance_log_time, message, message_time, message_type, informer_id) FROM stdin;
\.
COPY public.maintenance_log (maintenance_log_time, message, message_time, message_type, informer_id) FROM '$$PATH$$/2947.dat';

--
-- Data for Name: message; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.message (message_id, message, message_time, receiver_id, user_id) FROM stdin;
\.
COPY public.message (message_id, message, message_time, receiver_id, user_id) FROM '$$PATH$$/2948.dat';

--
-- Data for Name: shape; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shape (shape_id, arm_max_growth, arm_min_growth, hp_max_growth, hp_min_growth, str_max_growth, str_min_growth, baseline_arm, baseline_hp, baseline_str, image, name, speed) FROM stdin;
\.
COPY public.shape (shape_id, arm_max_growth, arm_min_growth, hp_max_growth, hp_min_growth, str_max_growth, str_min_growth, baseline_arm, baseline_hp, baseline_str, image, name, speed) FROM '$$PATH$$/2949.dat';

--
-- Data for Name: shape_skill; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shape_skill (shape_id, skill_id) FROM stdin;
\.
COPY public.shape_skill (shape_id, skill_id) FROM '$$PATH$$/2950.dat';

--
-- Data for Name: skill; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.skill (skill_id, cost, icon, name, tooltip) FROM stdin;
\.
COPY public.skill (skill_id, cost, icon, name, tooltip) FROM '$$PATH$$/2951.dat';

--
-- Data for Name: skill_effect; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.skill_effect (skill_effect_id, max_value, min_value, effect, target_type, value_modifier_type, skill_effect_bundle_id) FROM stdin;
\.
COPY public.skill_effect (skill_effect_id, max_value, min_value, effect, target_type, value_modifier_type, skill_effect_bundle_id) FROM '$$PATH$$/2952.dat';

--
-- Data for Name: skill_effect_bundle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.skill_effect_bundle (skill_effect_bundle_id, accuracy, skill_id) FROM stdin;
\.
COPY public.skill_effect_bundle (skill_effect_bundle_id, accuracy, skill_id) FROM '$$PATH$$/2953.dat';

--
-- Data for Name: skill_effect_result; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.skill_effect_result (skill_effect_result_id, result, effect, value_modifier_type, target_id, fight_action_id) FROM stdin;
\.
COPY public.skill_effect_result (skill_effect_result_id, result, effect, value_modifier_type, target_id, fight_action_id) FROM '$$PATH$$/2954.dat';

--
-- Data for Name: turn_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.turn_order (turn_order_id, turn_order, turn, fight_id, fighter_id) FROM stdin;
\.
COPY public.turn_order (turn_order_id, turn_order, turn, fight_id, fighter_id) FROM '$$PATH$$/2955.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, admin, email, xp_points, level, login, password, verified) FROM stdin;
\.
COPY public.users (user_id, admin, email, xp_points, level, login, password, verified) FROM '$$PATH$$/2956.dat';

--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hibernate_sequence', 321, true);


--
-- Name: changelog changelog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.changelog
    ADD CONSTRAINT changelog_pkey PRIMARY KEY (changelog_id);


--
-- Name: color_damage color_damage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.color_damage
    ADD CONSTRAINT color_damage_pkey PRIMARY KEY (color_damage_id);


--
-- Name: color color_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.color
    ADD CONSTRAINT color_pkey PRIMARY KEY (color_id);


--
-- Name: exp_threshold exp_threshold_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exp_threshold
    ADD CONSTRAINT exp_threshold_pkey PRIMARY KEY (exp_threshold_id);


--
-- Name: fight_action fight_action_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fight_action
    ADD CONSTRAINT fight_action_pkey PRIMARY KEY (fight_action_id);


--
-- Name: fight fight_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fight
    ADD CONSTRAINT fight_pkey PRIMARY KEY (fight_id);


--
-- Name: fighter_model_referrence fighter_model_referrence_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fighter_model_referrence
    ADD CONSTRAINT fighter_model_referrence_pkey PRIMARY KEY (fighter_model_referrence_id);


--
-- Name: fighter fighter_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fighter
    ADD CONSTRAINT fighter_pkey PRIMARY KEY (fighter_id);


--
-- Name: maintenance_log maintenance_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maintenance_log
    ADD CONSTRAINT maintenance_log_pkey PRIMARY KEY (maintenance_log_time);


--
-- Name: message message_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT message_pkey PRIMARY KEY (message_id);


--
-- Name: shape shape_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shape
    ADD CONSTRAINT shape_pkey PRIMARY KEY (shape_id);


--
-- Name: skill_effect_bundle skill_effect_bundle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skill_effect_bundle
    ADD CONSTRAINT skill_effect_bundle_pkey PRIMARY KEY (skill_effect_bundle_id);


--
-- Name: skill_effect skill_effect_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skill_effect
    ADD CONSTRAINT skill_effect_pkey PRIMARY KEY (skill_effect_id);


--
-- Name: skill_effect_result skill_effect_result_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skill_effect_result
    ADD CONSTRAINT skill_effect_result_pkey PRIMARY KEY (skill_effect_result_id);


--
-- Name: skill skill_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_pkey PRIMARY KEY (skill_id);


--
-- Name: turn_order turn_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.turn_order
    ADD CONSTRAINT turn_order_pkey PRIMARY KEY (turn_order_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: color_damage fk18a10ptgg0cxp7eltpa12f3hm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.color_damage
    ADD CONSTRAINT fk18a10ptgg0cxp7eltpa12f3hm FOREIGN KEY (enemy_color_id) REFERENCES public.color(color_id);


--
-- Name: skill_effect fk3826bfe17bqrcciu5qbr2xfyb; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skill_effect
    ADD CONSTRAINT fk3826bfe17bqrcciu5qbr2xfyb FOREIGN KEY (skill_effect_bundle_id) REFERENCES public.skill_effect_bundle(skill_effect_bundle_id);


--
-- Name: fight_action fk5m3p2fjmx8t9vgq4innmy7y56; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fight_action
    ADD CONSTRAINT fk5m3p2fjmx8t9vgq4innmy7y56 FOREIGN KEY (skill_id) REFERENCES public.skill(skill_id);


--
-- Name: fight_action fk660m911v3pvv4jr19uscrq7ao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fight_action
    ADD CONSTRAINT fk660m911v3pvv4jr19uscrq7ao FOREIGN KEY (next_active_fighter_id) REFERENCES public.fighter(fighter_id);


--
-- Name: turn_order fk777811or6q7bigrutklmtr9fy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.turn_order
    ADD CONSTRAINT fk777811or6q7bigrutklmtr9fy FOREIGN KEY (fighter_id) REFERENCES public.fighter(fighter_id);


--
-- Name: fight_action fk7naopspdwigwx4kkkordiu3d3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fight_action
    ADD CONSTRAINT fk7naopspdwigwx4kkkordiu3d3 FOREIGN KEY (active_fighter_id) REFERENCES public.fighter(fighter_id);


--
-- Name: fighter fk8x0dvybslh5crwie8ewrvb862; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fighter
    ADD CONSTRAINT fk8x0dvybslh5crwie8ewrvb862 FOREIGN KEY (owner_id) REFERENCES public.users(user_id);


--
-- Name: message fk9a25x9o5r7wguarxeon2a9tmr; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT fk9a25x9o5r7wguarxeon2a9tmr FOREIGN KEY (receiver_id) REFERENCES public.users(user_id);


--
-- Name: shape_skill fke5ru07hfapfsh7bcciyv6vm43; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shape_skill
    ADD CONSTRAINT fke5ru07hfapfsh7bcciyv6vm43 FOREIGN KEY (shape_id) REFERENCES public.shape(shape_id);


--
-- Name: turn_order fkegg49in9hu5id8i9r3ga9b1k; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.turn_order
    ADD CONSTRAINT fkegg49in9hu5id8i9r3ga9b1k FOREIGN KEY (fight_id) REFERENCES public.fight(fight_id);


--
-- Name: color_damage fkfxbq0368r5s8ry7bcyo6myaoq; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.color_damage
    ADD CONSTRAINT fkfxbq0368r5s8ry7bcyo6myaoq FOREIGN KEY (color_id) REFERENCES public.color(color_id);


--
-- Name: fight_action fkgh3bm4y5ijot1plmpheyi8qsp; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fight_action
    ADD CONSTRAINT fkgh3bm4y5ijot1plmpheyi8qsp FOREIGN KEY (fight_id) REFERENCES public.fight(fight_id);


--
-- Name: shape_skill fkh3lerpnovx82n9uajfrpogyd8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shape_skill
    ADD CONSTRAINT fkh3lerpnovx82n9uajfrpogyd8 FOREIGN KEY (skill_id) REFERENCES public.skill(skill_id);


--
-- Name: fight fki0nknax7aj367khy9sq57xtdb; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fight
    ADD CONSTRAINT fki0nknax7aj367khy9sq57xtdb FOREIGN KEY (player_one_id) REFERENCES public.users(user_id);


--
-- Name: fighter_model_referrence fki9tk5qmt9r965ap0mq3pv2gdx; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fighter_model_referrence
    ADD CONSTRAINT fki9tk5qmt9r965ap0mq3pv2gdx FOREIGN KEY (color_id) REFERENCES public.color(color_id);


--
-- Name: fighter_model_referrence fkiesbf6j13qx079v4y5xryfxpu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fighter_model_referrence
    ADD CONSTRAINT fkiesbf6j13qx079v4y5xryfxpu FOREIGN KEY (shape_id) REFERENCES public.shape(shape_id);


--
-- Name: maintenance_log fknmbn3c2ljq5vp9savq8q47gqm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maintenance_log
    ADD CONSTRAINT fknmbn3c2ljq5vp9savq8q47gqm FOREIGN KEY (informer_id) REFERENCES public.users(user_id);


--
-- Name: skill_effect_result fkogu37rk23alice6q3y66uv0o; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skill_effect_result
    ADD CONSTRAINT fkogu37rk23alice6q3y66uv0o FOREIGN KEY (fight_action_id) REFERENCES public.fight_action(fight_action_id);


--
-- Name: skill_effect_bundle fkomtaxe0l3f597o5hp4oym8wsu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skill_effect_bundle
    ADD CONSTRAINT fkomtaxe0l3f597o5hp4oym8wsu FOREIGN KEY (skill_id) REFERENCES public.skill(skill_id);


--
-- Name: fight_action fkormhlqtpt50orucmufj1oim3c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fight_action
    ADD CONSTRAINT fkormhlqtpt50orucmufj1oim3c FOREIGN KEY (selected_target_id) REFERENCES public.fighter(fighter_id);


--
-- Name: fighter fkp5apnjvedx4bpexo4qxbabg68; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fighter
    ADD CONSTRAINT fkp5apnjvedx4bpexo4qxbabg68 FOREIGN KEY (fighter_model_referrence_id) REFERENCES public.fighter_model_referrence(fighter_model_referrence_id);


--
-- Name: message fkpdrb79dg3bgym7pydlf9k3p1n; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT fkpdrb79dg3bgym7pydlf9k3p1n FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: skill_effect_result fks6m44tm1vcpqjisuwlmhofex; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skill_effect_result
    ADD CONSTRAINT fks6m44tm1vcpqjisuwlmhofex FOREIGN KEY (target_id) REFERENCES public.fighter(fighter_id);


--
-- Name: fight fkt90a421ox2eo9jqrmf68e7cl3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fight
    ADD CONSTRAINT fkt90a421ox2eo9jqrmf68e7cl3 FOREIGN KEY (player_two_id) REFERENCES public.users(user_id);


--
-- PostgreSQL database dump complete
--

